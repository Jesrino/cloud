package com.example.coffeeshop.model;

public enum OrderStatus {
    PENDING,
    READY,
    PAID
}