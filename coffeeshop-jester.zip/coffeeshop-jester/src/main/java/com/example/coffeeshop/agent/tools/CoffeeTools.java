package com.example.coffeeshop.agent.tools;

import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.model.Order;
import com.example.coffeeshop.service.MenuService;
import com.example.coffeeshop.service.OrderService;
import org.springframework.ai.tool.annotation.Tool;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class CoffeeTools {
    private final MenuService menuService;
    private final OrderService orderService;

    public CoffeeTools(MenuService menuService, OrderService orderService) {
        this.menuService = menuService;
        this.orderService = orderService;
    }

    @Tool(description = "Search the menu for items in a given category")
    public String searchMenu(String category) {
        List<MenuItem> items = menuService.getByCategory(category);
        if (items.isEmpty()) {
            return "No menu items found in category: " + category;
        }
        return items.stream()
                .map(this::describe)
                .collect(Collectors.joining("\n"));
    }

    @Tool(description = "List all menu items currently available to order")
    public String listAvailableItems() {
        List<MenuItem> items = menuService.getAvailableItems();
        if (items.isEmpty()) {
            return "There are no available items right now.";
        }
        return items.stream()
                .map(this::describe)
                .collect(Collectors.joining("\n"));
    }

    @Tool(description = "Place a new order given a list of menu item IDs; returns order id and total")
    public String placeOrder(List<Long> itemIds) {
        Order order = orderService.createOrder(itemIds);
        return "Created order " + order.getId()
                + " with status " + order.getStatus()
                + ". Total: " + order.getTotal();
    }

    @Tool(description = "Mark an order ready for pickup, by order ID")
    public String markOrderReady(Long orderId) {
        Order order = orderService.markReady(orderId);
        return "Order " + order.getId()
                + " is now " + order.getStatus();
    }

    @Tool(description = "Mark an order as paid, by order ID")
    public String payOrder(Long orderId) {
        Order order = orderService.markPaid(orderId);
        return "Order " + order.getId()
                + " is now " + order.getStatus();
    }

    private String describe(MenuItem item) {
        return "#" + item.getId()
                + " " + item.getName()
                + " (" + item.getCategory()
                + ") - " + item.getPrice()
                + (item.isAvailable() ? "" : " [SOLD OUT]");
    }
}