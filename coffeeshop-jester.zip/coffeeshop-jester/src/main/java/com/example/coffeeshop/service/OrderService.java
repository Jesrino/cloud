package com.example.coffeeshop.service;

import com.example.coffeeshop.exception.*;
import com.example.coffeeshop.model.*;
import com.example.coffeeshop.repository.*;
import org.slf4j.*;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class OrderService {
    private static final Logger log = LoggerFactory.getLogger(OrderService.class);
    private final OrderRepository orderRepo;
    private final MenuItemRepository menuRepo;

    public OrderService(OrderRepository orderRepo, MenuItemRepository menuRepo) {
        this.orderRepo = orderRepo;
        this.menuRepo = menuRepo;
    }

    public List<Order> getAllOrders() {
        return orderRepo.findAll();
    }

    public Order getOrderById(Long id) {
        return orderRepo.findById(id)
                .orElseThrow(() -> new OrderNotFoundException(id));
    }

    public Order createOrder(List<Long> itemIds) {
        if (itemIds == null || itemIds.isEmpty()) {
            throw new InvalidOrderException("Order must contain at least one item.");
        }
        BigDecimal total = BigDecimal.ZERO;
        for (Long itemId : itemIds) {
            MenuItem item = menuRepo.findById(itemId)
                    .orElseThrow(() -> new MenuItemNotFoundException(itemId));
            if (!item.isAvailable()) {
                throw new InvalidOrderException("Menu item " + itemId + " is not available.");
            }
            total = total.add(item.getPrice());
        }
        Order saved = orderRepo.save(new Order(itemIds, total));
        log.info("Created order {} with total {}", saved.getId(), total);
        return saved;
    }

    public Order markReady(Long id) {
        Order order = getOrderById(id);
        if (order.getStatus() != OrderStatus.PENDING) {
            throw new InvalidStatusTransitionException(
                    order.getStatus(), OrderStatus.READY);
        }
        order.setStatus(OrderStatus.READY);
        return orderRepo.save(order);
    }

    public Order markPaid(Long id) {
        Order order = getOrderById(id);
        if (order.getStatus() != OrderStatus.READY) {
            throw new InvalidStatusTransitionException(
                    order.getStatus(), OrderStatus.PAID);
        }
        order.setStatus(OrderStatus.PAID);
        return orderRepo.save(order);
    }
}