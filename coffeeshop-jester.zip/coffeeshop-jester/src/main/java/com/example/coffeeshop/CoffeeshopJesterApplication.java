package com.example.coffeeshop;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CoffeeshopJesterApplication {

	public static void main(String[] args) {
		SpringApplication.run(CoffeeshopJesterApplication.class, args);
	}

}
