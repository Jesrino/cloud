package com.example.coffeeshop.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class MenuItemRequest {
    @NotBlank(message = "name is required")
    private String name;

    @NotBlank(message = "category is required")
    private String category;

    @NotNull(message = "price is required")
    @DecimalMin(
            value = "0.0",
            inclusive = false,
            message = "price must be greater than 0"
    )
    private BigDecimal price;

    private boolean available = true;

    public MenuItemRequest() {
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }
}