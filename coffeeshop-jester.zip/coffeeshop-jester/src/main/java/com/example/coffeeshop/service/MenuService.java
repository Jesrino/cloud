package com.example.coffeeshop.service;

import com.example.coffeeshop.exception.MenuItemNotFoundException;
import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.repository.MenuItemRepository;
import org.slf4j.*;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MenuService {
    private static final Logger log = LoggerFactory.getLogger(MenuService.class);
    private final MenuItemRepository repo;

    public MenuService(MenuItemRepository repo) {
        this.repo = repo;
    }

    public List<MenuItem> getAllItems() {
        return repo.findAll();
    }

    public MenuItem getItemById(Long id) {
        return repo.findById(id)
                .orElseThrow(() -> new MenuItemNotFoundException(id));
    }

    public MenuItem createItem(MenuItem item) {
        MenuItem saved = repo.save(item);
        log.info("Created menu item {}", saved.getId());
        return saved;
    }

    public MenuItem updateItem(Long id, MenuItem updated) {
        MenuItem existing = getItemById(id);

        existing.setName(updated.getName());
        existing.setCategory(updated.getCategory());
        existing.setPrice(updated.getPrice());
        existing.setAvailable(updated.isAvailable());

        return repo.save(existing);
    }

    public void deleteItem(Long id) {
        MenuItem existing = getItemById(id);
        repo.delete(existing);
    }

    public List<MenuItem> getByCategory(String category) {
        return repo.findByCategoryIgnoreCase(category);
    }

    public List<MenuItem> getAvailableItems() {
        return repo.findByAvailableTrue();
    }
}
