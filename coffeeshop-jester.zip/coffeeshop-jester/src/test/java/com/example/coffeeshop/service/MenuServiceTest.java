package com.example.coffeeshop.service;

import com.example.coffeeshop.exception.MenuItemNotFoundException;
import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.repository.MenuItemRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

class MenuServiceTest {
    @Mock
    MenuItemRepository repo;

    @InjectMocks
    MenuService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void getItemById_returnsItem_whenPresent() {
        MenuItem latte = new MenuItem("Latte", "Coffee", new BigDecimal("3.75"), true);
        when(repo.findById(1L)).thenReturn(Optional.of(latte));
        MenuItem result = service.getItemById(1L);
        assertEquals("Latte", result.getName());
    }

    @Test
    void getItemById_throws_whenMissing() {
        when(repo.findById(99L)).thenReturn(Optional.empty());
        assertThrows(
                MenuItemNotFoundException.class,
                () -> service.getItemById(99L)
        );
    }

    @Test
    void createItem_savesAndReturns() {
        MenuItem latte = new MenuItem("Latte", "Coffee", new BigDecimal("3.75"), true);
        when(repo.save(any(MenuItem.class))).thenReturn(latte);
        MenuItem result = service.createItem(latte);
        assertEquals("Latte", result.getName());
        verify(repo, times(1)).save(latte);
    }
}