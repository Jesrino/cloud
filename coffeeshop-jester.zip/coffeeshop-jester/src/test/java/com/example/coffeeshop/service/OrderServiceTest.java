package com.example.coffeeshop.service;

import com.example.coffeeshop.exception.InvalidOrderException;
import com.example.coffeeshop.exception.InvalidStatusTransitionException;
import com.example.coffeeshop.model.MenuItem;
import com.example.coffeeshop.model.Order;
import com.example.coffeeshop.model.OrderStatus;
import com.example.coffeeshop.repository.MenuItemRepository;
import com.example.coffeeshop.repository.OrderRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

class OrderServiceTest {
    @Mock
    OrderRepository orderRepo;

    @Mock
    MenuItemRepository menuRepo;

    @InjectMocks
    OrderService service;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    void createOrder_computesCorrectTotal() {
        MenuItem latte = new MenuItem(
                "Latte",
                "Coffee",
                new BigDecimal("3.75"),
                true
        );
        latte.setId(1L);

        MenuItem croissant = new MenuItem(
                "Croissant",
                "Pastry",
                new BigDecimal("2.95"),
                true
        );
        croissant.setId(2L);

        when(menuRepo.findById(1L)).thenReturn(Optional.of(latte));
        when(menuRepo.findById(2L)).thenReturn(Optional.of(croissant));
        when(orderRepo.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));
        Order result = service.createOrder(Arrays.asList(1L, 2L));
        assertEquals(new BigDecimal("6.70"), result.getTotal());
        assertEquals(OrderStatus.PENDING, result.getStatus());
    }

    @Test
    void createOrder_emptyList_throws() {
        assertThrows(
                InvalidOrderException.class,
                () -> service.createOrder(Collections.emptyList())
        );
    }

    @Test
    void markReady_fromPending_succeeds() {
        Order order = new Order(
                List.of(1L),
                new BigDecimal("3.75")
        );
        order.setStatus(OrderStatus.PENDING);
        when(orderRepo.findById(1L)).thenReturn(Optional.of(order));
        when(orderRepo.save(any(Order.class))).thenAnswer(invocation -> invocation.getArgument(0));
        Order result = service.markReady(1L);
        assertEquals(OrderStatus.READY, result.getStatus());
    }

    @Test
    void markPaid_fromPending_throws() {
        Order order = new Order(
                List.of(1L),
                new BigDecimal("3.75")
        );
        order.setStatus(OrderStatus.PENDING);
        when(orderRepo.findById(1L)).thenReturn(Optional.of(order));
        assertThrows(
                InvalidStatusTransitionException.class,
                () -> service.markPaid(1L)
        );
    }
}