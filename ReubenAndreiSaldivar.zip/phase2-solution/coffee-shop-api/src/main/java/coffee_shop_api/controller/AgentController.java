package coffee_shop_api.controller;

import coffee_shop_api.model.MenuItem;
import coffee_shop_api.model.Order;
import coffee_shop_api.repository.MenuItemRepository;
import coffee_shop_api.repository.OrderRepository;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/agent")
public class AgentController {

    private final MenuItemRepository menuItemRepository;
    private final OrderRepository orderRepository;

    public AgentController(
            MenuItemRepository menuItemRepository,
            OrderRepository orderRepository) {

        this.menuItemRepository = menuItemRepository;
        this.orderRepository = orderRepository;
    }

    @PostMapping
    public ResponseEntity<String> askAgent(
            @RequestBody String message) {

        if (message == null || message.isBlank()) {
            return ResponseEntity.badRequest()
                    .body("Please ask me a question.");
        }

        String lowerMessage = message.toLowerCase();

        // Step 1: Show available coffees
        if (lowerMessage.contains("available")
                && lowerMessage.contains("coffee")
                && lowerMessage.contains("order")
                && lowerMessage.contains("latte")) {

            List<MenuItem> availableItems =
                    menuItemRepository.findAll()
                            .stream()
                            .filter(MenuItem::isAvailable)
                            .toList();

            StringBuilder response = new StringBuilder();

            response.append("Available coffees: ");

            availableItems.stream()
                    .filter(item ->
                            "Coffee".equalsIgnoreCase(
                                    item.getCategory()))
                    .forEach(item ->
                            response.append(item.getName())
                                    .append(" (₱")
                                    .append(item.getPrice())
                                    .append("), "));

            // Step 2: Find Latte
            MenuItem latte = availableItems.stream()
                    .filter(item ->
                            "Latte".equalsIgnoreCase(
                                    item.getName()))
                    .findFirst()
                    .orElse(null);

            if (latte == null) {
                return ResponseEntity.ok(
                        response +
                        "Unfortunately, Latte is currently unavailable."
                );
            }

            // Step 3: Create the order
            Order order = new Order(
                    String.valueOf(latte.getId()),
                    "PENDING",
                    latte.getPrice()
            );

            Order savedOrder = orderRepository.save(order);

            // Step 4: Tell the user what happened
            response.append("\n\n")
                    .append("I ordered a Latte for you. ")
                    .append("Order #")
                    .append(savedOrder.getId())
                    .append(". ")
                    .append("Your total is ₱")
                    .append(latte.getPrice())
                    .append(".");

            return ResponseEntity.ok(
                    response.toString()
            );
        }

        // Simple available-coffee request
        if (lowerMessage.contains("available")
                && lowerMessage.contains("coffee")) {

            List<MenuItem> coffees =
                    menuItemRepository.findAll()
                            .stream()
                            .filter(MenuItem::isAvailable)
                            .filter(item ->
                                    "Coffee".equalsIgnoreCase(
                                            item.getCategory()))
                            .toList();

            if (coffees.isEmpty()) {
                return ResponseEntity.ok(
                        "There are currently no available coffees."
                );
            }

            StringBuilder response =
                    new StringBuilder("Available coffees: ");

            coffees.forEach(item ->
                    response.append(item.getName())
                            .append(" (₱")
                            .append(item.getPrice())
                            .append("), "));

            return ResponseEntity.ok(
                    response.toString()
            );
        }

        // Recommendation
        if (lowerMessage.contains("recommend")) {

            MenuItem recommendation =
                    menuItemRepository.findAll()
                            .stream()
                            .filter(MenuItem::isAvailable)
                            .filter(item ->
                                    "Coffee".equalsIgnoreCase(
                                            item.getCategory()))
                            .findFirst()
                            .orElse(null);

            if (recommendation == null) {
                return ResponseEntity.ok(
                        "I don't have an available coffee to recommend right now."
                );
            }

            return ResponseEntity.ok(
                    "I recommend the "
                            + recommendation.getName()
                            + " for ₱"
                            + recommendation.getPrice()
                            + "."
            );
        }

        return ResponseEntity.ok(
                "AI Barista: I can show available coffees, "
                        + "give recommendations, or place an order."
        );
    }
}