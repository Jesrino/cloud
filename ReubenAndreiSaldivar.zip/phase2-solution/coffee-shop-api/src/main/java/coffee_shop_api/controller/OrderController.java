package coffee_shop_api.controller;

import coffee_shop_api.model.MenuItem;
import coffee_shop_api.model.Order;
import coffee_shop_api.repository.MenuItemRepository;
import coffee_shop_api.repository.OrderRepository;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

@CrossOrigin(origins = "http://localhost:5173")
@RestController
@RequestMapping("/orders")
public class OrderController {

    private final OrderRepository orderRepository;
    private final MenuItemRepository menuItemRepository;

    public OrderController(
            OrderRepository orderRepository,
            MenuItemRepository menuItemRepository) {

        this.orderRepository = orderRepository;
        this.menuItemRepository = menuItemRepository;
    }

    // POST /orders
    @PostMapping
    public ResponseEntity<OrderResponse> createOrder(
            @RequestBody CreateOrderRequest request) {

        List<Long> itemIds = request.itemIds();

        if (itemIds == null || itemIds.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        double total = 0.0;

        for (Long itemId : itemIds) {

            MenuItem item = menuItemRepository.findById(itemId)
                    .orElse(null);

            if (item == null || !item.isAvailable()) {
                return ResponseEntity.badRequest().build();
            }

            total += item.getPrice();
        }

        String storedItemIds = itemIds.stream()
                .map(String::valueOf)
                .reduce((a, b) -> a + "," + b)
                .orElse("");

        Order order = new Order(
                storedItemIds,
                "PENDING",
                total
        );

        Order savedOrder = orderRepository.save(order);

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(toResponse(savedOrder));
    }

    // GET /orders
    @GetMapping
    public ResponseEntity<List<OrderResponse>> getAllOrders() {

        List<OrderResponse> orders = orderRepository.findAll()
                .stream()
                .map(this::toResponse)
                .toList();

        return ResponseEntity.ok(orders);
    }

    // POST /orders/{id}/ready
    @PostMapping("/{id}/ready")
    public ResponseEntity<OrderResponse> markOrderReady(
            @PathVariable Long id) {

        Order order = orderRepository.findById(id)
                .orElse(null);

        if (order == null) {
            return ResponseEntity.notFound().build();
        }

        if (!"PENDING".equals(order.getStatus())) {
            return ResponseEntity.badRequest().build();
        }

        order.setStatus("READY");

        Order savedOrder = orderRepository.save(order);

        return ResponseEntity.ok(toResponse(savedOrder));
    }

    // POST /orders/{id}/pay
    @PostMapping("/{id}/pay")
    public ResponseEntity<OrderResponse> payOrder(
            @PathVariable Long id) {

        Order order = orderRepository.findById(id)
                .orElse(null);

        if (order == null) {
            return ResponseEntity.notFound().build();
        }

        if (!"READY".equals(order.getStatus())) {
            return ResponseEntity.badRequest().build();
        }

        order.setStatus("PAID");

        Order savedOrder = orderRepository.save(order);

        return ResponseEntity.ok(toResponse(savedOrder));
    }

    private OrderResponse toResponse(Order order) {

        List<Long> itemIds = new ArrayList<>();

        if (order.getItemIds() != null
                && !order.getItemIds().isBlank()) {

            itemIds = Arrays.stream(order.getItemIds().split(","))
                    .map(Long::valueOf)
                    .toList();
        }

        return new OrderResponse(
                order.getId(),
                itemIds,
                order.getStatus(),
                order.getTotal()
        );
    }

    public record CreateOrderRequest(
            List<Long> itemIds
    ) {
    }

    public record OrderResponse(
            Long id,
            List<Long> itemIds,
            String status,
            double total
    ) {
    }
}