package coffee_shop_api;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import coffee_shop_api.model.MenuItem;
import coffee_shop_api.repository.MenuItemRepository;

@SpringBootApplication
public class CoffeeShopApiApplication {

    public static void main(String[] args) {
        SpringApplication.run(CoffeeShopApiApplication.class, args);
    }

    @Bean
    CommandLineRunner seedMenu(MenuItemRepository repository) {
        return args -> {

            if (repository.count() == 0) {

                repository.save(
                    new MenuItem("Espresso", "Coffee", 100.00, true)
                );

                repository.save(
                    new MenuItem("Latte", "Coffee", 140.00, true)
                );

                repository.save(
                    new MenuItem("Cappuccino", "Coffee", 150.00, true)
                );

                repository.save(
                    new MenuItem("Mocha", "Coffee", 160.00, true)
                );

                repository.save(
                    new MenuItem("Iced Tea", "Tea", 110.00, true)
                );
            }
        };
    }
}