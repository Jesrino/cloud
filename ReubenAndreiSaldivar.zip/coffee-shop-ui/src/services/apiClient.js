// API client service for all backend calls
const API_BASE_URL = 'http://localhost:8080';

class APIError extends Error {
  constructor(message, status) {
    super(message);
    this.status = status;
    this.name = 'APIError';
  }
}

// Centralized fetch wrapper
async function apiCall(endpoint, options = {}) {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const defaultOptions = {
    headers: {
      'Content-Type': 'application/json',
    },
  };

  const response = await fetch(url, { ...defaultOptions, ...options });
  
  if (!response.ok) {
    let errorMessage = `HTTP ${response.status}`;
    try {
      const errorData = await response.json();
      errorMessage = errorData.message || errorMessage;
    } catch (e) {
      // Response is not JSON, use status message
      errorMessage = response.statusText || errorMessage;
    }
    throw new APIError(errorMessage, response.status);
  }

  // Handle 204 No Content
  if (response.status === 204) {
    return null;
  }

  try {
    return await response.json();
  } catch (e) {
    // Response is not JSON, return empty object
    return {};
  }
}

// Menu endpoints
export const menuAPI = {
  async getAll() {
    return apiCall('/menu');
  },

  async getAvailable() {
    return apiCall('/menu/available');
  },

  async getById(id) {
    return apiCall(`/menu/${id}`);
  },

  async create(item) {
    return apiCall('/menu', {
      method: 'POST',
      body: JSON.stringify(item),
    });
  },

  async update(id, item) {
    return apiCall(`/menu/${id}`, {
      method: 'PUT',
      body: JSON.stringify(item),
    });
  },

  async delete(id) {
    return apiCall(`/menu/${id}`, {
      method: 'DELETE',
    });
  },
};

// Orders endpoints
export const ordersAPI = {
  async getAll() {
    return apiCall('/orders');
  },

  async create(orderData) {
    return apiCall('/orders', {
      method: 'POST',
      body: JSON.stringify(orderData),
    });
  },

  async markReady(id) {
    return apiCall(`/orders/${id}/ready`, {
      method: 'POST',
    });
  },

  async markPaid(id) {
    return apiCall(`/orders/${id}/pay`, {
      method: 'POST',
    });
  },
};

// AI Agent endpoints
export const agentAPI = {
  async chat(message) {
    const response = await fetch(`${API_BASE_URL}/agent`, {
      method: 'POST',
      headers: {
        'Content-Type': 'text/plain',
      },
      body: message,
    });

    if (!response.ok) {
      throw new APIError(`HTTP ${response.status}`, response.status);
    }

    return await response.text();
  },
};

export default apiCall;
