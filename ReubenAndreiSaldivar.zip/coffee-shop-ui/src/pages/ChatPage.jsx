import { useState, useEffect, useRef } from 'react';
import { agentAPI } from '../services/apiClient';
import './ChatPage.css';

export function ChatPage() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e) => {
    e.preventDefault();
    
    if (!input.trim()) {
      return;
    }

    const userMessage = input.trim();
    setInput('');
    setError(null);

    // Add user message to chat
    setMessages(prev => [...prev, {
      id: Date.now(),
      type: 'user',
      text: userMessage,
      timestamp: new Date(),
    }]);

    setLoading(true);

    try {
      // Call the agent API
      const response = await agentAPI.chat(userMessage);

      // Add agent response to chat
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        type: 'agent',
        text: response,
        timestamp: new Date(),
      }]);
    } catch (err) {
      setError(err.message);
      console.error('Failed to get agent response:', err);

      // Add error message to chat
      setMessages(prev => [...prev, {
        id: Date.now() + 1,
        type: 'error',
        text: `Error: ${err.message}`,
        timestamp: new Date(),
      }]);
    } finally {
      setLoading(false);
    }
  };

  const suggestedPrompts = [
    'Show available coffees',
    'What pastries do you have?',
    'Order a latte and a croissant',
    'What\'s the total for a cappuccino and espresso?',
  ];

  const handleSuggestedPrompt = (prompt) => {
    setInput(prompt);
  };

  return (
    <div className="chat-page">
      <div className="chat-container">
        <div className="chat-header">
          <h1>Barista AI Chat</h1>
          <p>Ask me about our menu, place orders, or get recommendations</p>
        </div>

        <div className="messages-container">
          {messages.length === 0 ? (
            <div className="welcome-message">
              <h2>Welcome to Barista AI</h2>
              <p>I can help you browse our menu, answer questions, and place orders.</p>
              <p>Try one of these prompts to get started:</p>
              <div className="suggested-prompts">
                {suggestedPrompts.map((prompt, idx) => (
                  <button
                    key={idx}
                    className="prompt-button"
                    onClick={() => handleSuggestedPrompt(prompt)}
                  >
                    {prompt}
                  </button>
                ))}
              </div>
            </div>
          ) : (
            <>
              {messages.map(message => (
                <div
                  key={message.id}
                  className={`message message-${message.type}`}
                >
                  <div className="message-content">
                    {message.type === 'agent' && <span className="agent-label">🤖</span>}
                    {message.type === 'user' && <span className="user-label">👤</span>}
                    <p className="message-text">{message.text}</p>
                  </div>
                  <span className="message-time">
                    {message.timestamp.toLocaleTimeString([], {
                      hour: '2-digit',
                      minute: '2-digit',
                    })}
                  </span>
                </div>
              ))}
              {loading && (
                <div className="message message-loading">
                  <div className="message-content">
                    <span className="agent-label">🤖</span>
                    <div className="typing-indicator">
                      <span></span>
                      <span></span>
                      <span></span>
                    </div>
                  </div>
                </div>
              )}
              <div ref={messagesEndRef} />
            </>
          )}
        </div>

        {error && (
          <div className="error-banner">
            {error}
          </div>
        )}

        <form className="message-input-form" onSubmit={handleSendMessage}>
          <input
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder="Ask about menu, place an order, or chat..."
            disabled={loading}
            autoFocus
          />
          <button
            type="submit"
            disabled={loading || !input.trim()}
            className="send-button"
          >
            {loading ? '⏳' : '➤'}
          </button>
        </form>
      </div>
    </div>
  );
}
