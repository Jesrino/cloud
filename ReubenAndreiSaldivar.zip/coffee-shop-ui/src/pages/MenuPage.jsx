import { useState } from 'react';
import { MenuForm } from '../components/MenuForm';
import { MenuList } from '../components/MenuList';
import { useMenu } from '../hooks/useMenu';
import './MenuPage.css';

export function MenuPage() {
  const { items, loading, error, addItem, deleteItem } = useMenu();
  const [showForm, setShowForm] = useState(false);
  const [submitError, setSubmitError] = useState(null);
  const [submitLoading, setSubmitLoading] = useState(false);

  const handleAddItem = async (formData) => {
    setSubmitLoading(true);
    setSubmitError(null);
    try {
      await addItem(formData);
      setShowForm(false);
      setSubmitError(null);
    } catch (err) {
      setSubmitError(err.message);
    } finally {
      setSubmitLoading(false);
    }
  };

  const handleDeleteItem = async (id) => {
    try {
      await deleteItem(id);
    } catch (err) {
      alert(`Failed to delete item: ${err.message}`);
    }
  };

  return (
    <div className="menu-page">
      <div className="page-header">
        <h1>Menu Management</h1>
        <button
          className="btn btn-primary"
          onClick={() => setShowForm(!showForm)}
        >
          {showForm ? 'Cancel' : 'Add New Item'}
        </button>
      </div>

      {showForm && (
        <div className="form-section">
          <h2>Add New Menu Item</h2>
          {submitError && <div className="error-message">{submitError}</div>}
          <MenuForm
            onSubmit={handleAddItem}
            loading={submitLoading}
          />
        </div>
      )}

      <div className="list-section">
        <h2>All Menu Items</h2>
        <MenuList
          items={items}
          onDelete={handleDeleteItem}
          loading={loading}
          error={error}
        />
      </div>
    </div>
  );
}
