import { useParams, useNavigate } from 'react-router-dom';
import { useState, useEffect } from 'react';
import { MenuForm } from '../components/MenuForm';
import { useMenu } from '../hooks/useMenu';
import './EditMenuPage.css';

export function EditMenuPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { items, updateItem, loading: menuLoading } = useMenu();
  const [submitLoading, setSubmitLoading] = useState(false);
  const [error, setError] = useState(null);
  const [item, setItem] = useState(null);

  useEffect(() => {
    // 1. If id is completely missing (router mismatch), don't try to search
    if (!id) return;

    // 2. Safely compare IDs by converting both to strings
    const foundItem = items.find(i => String(i.id) === String(id));

    if (foundItem) {
      setItem(foundItem);
      setError(null); // ✅ Clear the error if we successfully found it
    } else if (!menuLoading && items.length > 0) {
      // ✅ Only trigger "not found" if loading finished AND we actually checked a full list
      setError('Item not found');
    }
  }, [items, id, menuLoading]);

  const handleUpdate = async (formData) => {
    setSubmitLoading(true);
    try {
      await updateItem(parseInt(id), formData);
      navigate('/menu');
    } catch (err) {
      setError(err.message);
    } finally {
      setSubmitLoading(false);
    }
  };

  if (menuLoading) {
    return <div className="loading-page">Loading...</div>;
  }

  if (error) {
    return (
      <div className="edit-menu-page">
        <div className="error-message">{error}</div>
        <button onClick={() => navigate('/menu')} className="btn btn-primary">
          Back to Menu
        </button>
      </div>
    );
  }

  if (!item) {
    return <div className="loading-page">Loading item...</div>;
  }

  return (
    <div className="edit-menu-page">
      <div className="page-header">
        <h1>Edit Menu Item</h1>
        <button onClick={() => navigate('/menu')} className="btn btn-secondary">
          Cancel
        </button>
      </div>

      <div className="form-container">
        <MenuForm
          item={item}
          onSubmit={handleUpdate}
          loading={submitLoading}
        />
      </div>
    </div>
  );
}
