import { useState, useEffect } from 'react';
import { ordersAPI, menuAPI } from '../services/apiClient';
import './OrdersPage.css';

export function OrdersPage() {
  const [orders, setOrders] = useState([]);
  const [menuItems, setMenuItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [selectedItems, setSelectedItems] = useState([]);
  const [showOrderForm, setShowOrderForm] = useState(false);
  const [orderLoading, setOrderLoading] = useState(false);

  // Fetch orders and menu items on mount
  useEffect(() => {
    fetchOrders();
    fetchMenuItems();
  }, []);

  const fetchOrders = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await ordersAPI.getAll();
      setOrders(data);
    } catch (err) {
      setError(err.message);
      console.error('Failed to fetch orders:', err);
    } finally {
      setLoading(false);
    }
  };

  const fetchMenuItems = async () => {
    try {
      const data = await menuAPI.getAvailable();
      setMenuItems(data);
    } catch (err) {
      console.error('Failed to fetch menu items:', err);
    }
  };

  const handleItemSelect = (itemId) => {
    setSelectedItems(prev =>
      prev.includes(itemId)
        ? prev.filter(id => id !== itemId)
        : [...prev, itemId]
    );
  };

  const handlePlaceOrder = async () => {
    if (selectedItems.length === 0) {
      alert('Please select at least one item');
      return;
    }

    setOrderLoading(true);
    try {
      const newOrder = await ordersAPI.create({ itemIds: selectedItems });
      setOrders([...orders, newOrder]);
      setSelectedItems([]);
      setShowOrderForm(false);
    } catch (err) {
      setError(err.message);
      alert(`Failed to place order: ${err.message}`);
    } finally {
      setOrderLoading(false);
    }
  };

  const handleMarkReady = async (orderId) => {
    try {
      const updated = await ordersAPI.markReady(orderId);
      setOrders(orders.map(order => order.id === orderId ? updated : order));
    } catch (err) {
      alert(`Failed to mark order as ready: ${err.message}`);
    }
  };

  const handleMarkPaid = async (orderId) => {
    try {
      const updated = await ordersAPI.markPaid(orderId);
      setOrders(orders.map(order => order.id === orderId ? updated : order));
    } catch (err) {
      alert(`Failed to mark order as paid: ${err.message}`);
    }
  };

  const getItemName = (itemId) => {
    const item = menuItems.find(m => m.id === itemId);
    return item ? item.name : `Item ${itemId}`;
  };

  if (error && !showOrderForm) {
    return (
      <div className="orders-page">
        <div className="error-banner">{error}</div>
      </div>
    );
  }

  return (
    <div className="orders-page">
      <div className="page-header">
        <h1>Orders</h1>
        <button
          className="btn btn-primary"
          onClick={() => setShowOrderForm(!showOrderForm)}
        >
          {showOrderForm ? 'Cancel' : 'Place New Order'}
        </button>
      </div>

      {showOrderForm && (
        <div className="order-form-section">
          <h2>Place New Order</h2>
          <div className="items-selection">
            {menuItems.length === 0 ? (
              <p>No available items</p>
            ) : (
              menuItems.map(item => (
                <label key={item.id} className="item-checkbox">
                  <input
                    type="checkbox"
                    checked={selectedItems.includes(item.id)}
                    onChange={() => handleItemSelect(item.id)}
                    disabled={orderLoading}
                  />
                  <span>
                    {item.name} - ${item.price.toFixed(2)}
                  </span>
                </label>
              ))
            )}
          </div>

          {selectedItems.length > 0 && (
            <div className="order-summary">
              <p>
                Total: $
                {(
                  selectedItems.reduce((sum, itemId) => {
                    const item = menuItems.find(m => m.id === itemId);
                    return sum + (item?.price || 0);
                  }, 0)
                ).toFixed(2)}
              </p>
            </div>
          )}

          <button
            className="btn btn-primary"
            onClick={handlePlaceOrder}
            disabled={orderLoading || selectedItems.length === 0}
          >
            {orderLoading ? 'Placing Order...' : 'Place Order'}
          </button>
        </div>
      )}

      <div className="orders-list">
        <h2>All Orders</h2>
        {loading && <div className="loading">Loading orders...</div>}
        {orders.length === 0 && !loading && <div className="empty-state">No orders yet</div>}

        {orders.map(order => (
          <div key={order.id} className={`order-card status-${order.status.toLowerCase()}`}>
            <div className="order-header">
              <h3>Order #{order.id}</h3>
              <span className={`status-badge ${order.status.toLowerCase()}`}>
                {order.status}
              </span>
            </div>
            <div className="order-details">
              <p>
                <strong>Items:</strong> {order.itemIds.map(getItemName).join(', ')}
              </p>
              <p>
                <strong>Total:</strong> ${order.total.toFixed(2)}
              </p>
            </div>
            <div className="order-actions">
              {order.status === 'PENDING' && (
                <button
                  className="btn btn-primary btn-sm"
                  onClick={() => handleMarkReady(order.id)}
                >
                  Mark Ready
                </button>
              )}
              {order.status === 'READY' && (
                <button
                  className="btn btn-success btn-sm"
                  onClick={() => handleMarkPaid(order.id)}
                >
                  Mark Paid
                </button>
              )}
              {order.status === 'PAID' && (
                <span className="status-text">Completed</span>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
