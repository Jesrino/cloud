import { Link } from 'react-router-dom';
import './HomePage.css';

export function HomePage() {
  return (
    <div className="home-page">
      <div className="hero">
        <h1>☕ Coffee Shop</h1>
        <p>Your favorite place for great coffee and pastries</p>
      </div>

      <div className="features">
        <Link to="/menu" className="feature-card">
          <div className="feature-icon">📋</div>
          <h2>Menu Management</h2>
          <p>Browse and manage our menu items with full CRUD operations</p>
        </Link>

        <Link to="/orders" className="feature-card">
          <div className="feature-icon">📦</div>
          <h2>Orders</h2>
          <p>Place new orders and track their status</p>
        </Link>

        <Link to="/chat" className="feature-card">
          <div className="feature-icon">🤖</div>
          <h2>AI Barista</h2>
          <p>Chat with our AI assistant for recommendations and support</p>
        </Link>
      </div>

      <div className="info">
        <h2>About This App</h2>
        <p>
          This is a modern React + Vite application that demonstrates:
        </p>
        <ul>
          <li>✅ CRUD operations for menu management</li>
          <li>✅ React Router for navigation</li>
          <li>✅ Custom React hooks for state management</li>
          <li>✅ AI-powered chat with multi-step conversations</li>
          <li>✅ Clean component architecture</li>
          <li>✅ Error handling and loading states</li>
        </ul>
      </div>
    </div>
  );
}
