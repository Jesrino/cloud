import { useState, useEffect } from 'react';
import { menuAPI } from '../services/apiClient';

/**
 * Custom hook for managing menu items
 * Encapsulates menu data fetching and CRUD operations
 */
export function useMenu() {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  // Fetch all menu items
  const fetchItems = async () => {
    setLoading(true);
    setError(null);
    try {
      const data = await menuAPI.getAll();
      setItems(data);
    } catch (err) {
      setError(err.message);
      console.error('Failed to fetch menu items:', err);
    } finally {
      setLoading(false);
    }
  };

  // Fetch on mount
  useEffect(() => {
    fetchItems();
  }, []);

  // Add new item
  const addItem = async (newItem) => {
    try {
      const created = await menuAPI.create(newItem);
      setItems([...items, created]);
      return created;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Update existing item
  const updateItem = async (id, updatedItem) => {
    try {
      const updated = await menuAPI.update(id, updatedItem);
      setItems(items.map(item => item.id === id ? updated : item));
      return updated;
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Delete item
  const deleteItem = async (id) => {
    try {
      await menuAPI.delete(id);
      setItems(items.filter(item => item.id !== id));
    } catch (err) {
      setError(err.message);
      throw err;
    }
  };

  // Get single item by ID
  const getItemById = (id) => {
    return items.find(item => item.id === parseInt(id));
  };

  return {
    items,
    loading,
    error,
    fetchItems,
    addItem,
    updateItem,
    deleteItem,
    getItemById,
  };
}
