import { Link, useLocation } from 'react-router-dom';
import './Navigation.css';

export function Navigation() {
  const location = useLocation();

  const isActive = (path) => {
    return location.pathname === path ? 'active' : '';
  };

  return (
    <nav className="navigation">
      <div className="nav-container">
        <Link to="/" className="nav-brand">
          ☕ Coffee Shop UI
        </Link>

        <div className="nav-links">
          <Link to="/" className={`nav-link ${isActive('/')}`}>
            Home
          </Link>
          <Link to="/menu" className={`nav-link ${isActive('/menu')}`}>
            Menu
          </Link>
          <Link to="/orders" className={`nav-link ${isActive('/orders')}`}>
            Orders
          </Link>
          <Link to="/chat" className={`nav-link ${isActive('/chat')}`}>
            AI Barista
          </Link>
        </div>
      </div>
    </nav>
  );
}
