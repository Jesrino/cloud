import { Link } from 'react-router-dom';
import './MenuList.css';

export function MenuList({ items, onDelete, loading, error }) {
  const handleDelete = (id) => {
    if (confirm('Are you sure you want to delete this item?')) {
      onDelete(id);
    }
  };

  if (error) {
    return (
      <div className="error-banner">
        <p>Error: {error}</p>
      </div>
    );
  }

  if (loading) {
    return <div className="loading">Loading menu items...</div>;
  }

  if (items.length === 0) {
    return <div className="empty-state">No menu items available. Create one!</div>;
  }

  return (
    <div className="menu-list-container">
      <table className="menu-table">
        <thead>
          <tr>
            <th>Name</th>
            <th>Category</th>
            <th>Price</th>
            <th>Available</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {items.map((item) => (
            <tr key={item.id} className={!item.available ? 'unavailable' : ''}>
              <td>{item.name}</td>
              <td>{item.category}</td>
              <td>${item.price.toFixed(2)}</td>
              <td>
                <span className={`badge ${item.available ? 'available' : 'unavailable'}`}>
                  {item.available ? 'Yes' : 'No'}
                </span>
              </td>
              <td className="actions">
                <Link to={`/menu/${item.id}/edit`} className="btn btn-primary btn-sm">
                  Edit
                </Link>
                <button
                  className="btn btn-danger btn-sm"
                  onClick={() => handleDelete(item.id)}
                >
                  Delete
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
