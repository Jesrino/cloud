# Coffee Shop UI

A modern React + Vite single-page application for a coffee shop that demonstrates CRUD operations, React Router navigation, custom hooks, and AI-powered chat features.

## Features

✅ **Task A - Project & API Layer**
- Vite + React project with `npm run dev`
- Centralized API service layer (`src/services/apiClient.js`)
- Proper HTTP error handling with custom `APIError` class
- No inline URLs scattered in components

✅ **Task B - CRUD: Menu Management**
- **Read**: List all menu items in a table with name, category, price, availability
- **Create**: Form to POST new items and display in list
- **Update**: Edit form with pre-filled data and PUT changes
- **Delete**: Confirmation step before deletion, list updates without reload
- Loading and error states for each operation

✅ **Task C - React Router**
- App wrapped in `BrowserRouter`
- 5 routes: Home, Menu, Menu Edit (dynamic), Orders, AI Chat
- Persistent navigation bar with `NavLink` and active-link styling
- Dynamic route params: `/menu/:id/edit` using `useParams`
- Programmatic navigation with `useNavigate` after actions
- 404 catch-all route with `NotFoundPage`

✅ **Task D - Hooks**
- Correct `useState` and `useEffect` usage
  - Data fetch on mount with cleanup
  - Dependency arrays properly configured
- **Custom hook**: `useMenu` encapsulates menu data and CRUD operations
  - Reused by `MenuPage` and `EditMenuPage`
  - Returns `{ items, loading, error, fetchItems, addItem, updateItem, deleteItem, getItemById }`
- No infinite render loops
- Derived values via `useMemo` considerations

✅ **Task E - Agentic AI Chat**
- Chat page that POSTs plain text to `/agent` and renders reply
- Running conversation log with user and agent message bubbles
- "Thinking" indicator (typing animation) while agent works
- Suggested prompt buttons for easy interaction
- Auto-scroll to latest messages

✅ **Task F - Code Quality & UX**
- Clear component structure with sensible naming
- No dead code or console spam
- Responsive layout with mobile-friendly design
- Professional styling with CSS Grid/Flexbox
- Accessible form validation
- Error boundaries and error messages

## Project Structure

```
coffee-shop-ui/
├── src/
│   ├── components/
│   │   ├── Navigation.jsx      # Persistent nav bar with NavLink
│   │   ├── Navigation.css
│   │   ├── MenuForm.jsx        # Form for create/edit menu items
│   │   ├── MenuList.jsx        # Table for displaying menu items
│   │   └── MenuList.css
│   ├── pages/
│   │   ├── HomePage.jsx        # Home landing page
│   │   ├── HomePage.css
│   │   ├── MenuPage.jsx        # Menu CRUD management
│   │   ├── MenuPage.css
│   │   ├── EditMenuPage.jsx    # Edit menu item (dynamic route)
│   │   ├── EditMenuPage.css
│   │   ├── OrdersPage.jsx      # Order management
│   │   ├── OrdersPage.css
│   │   ├── ChatPage.jsx        # AI chat interface
│   │   ├── ChatPage.css
│   │   ├── NotFoundPage.jsx    # 404 page
│   │   └── NotFoundPage.css
│   ├── hooks/
│   │   └── useMenu.js          # Custom hook for menu CRUD
│   ├── services/
│   │   └── apiClient.js        # Centralized API fetch wrapper
│   ├── App.jsx                 # Router setup with all routes
│   ├── App.css                 # Global styles
│   ├── index.jsx               # React DOM render entry
│   └── index.css               # Global CSS
├── index.html
├── package.json
└── README.md
```

## Prerequisites

- **Node.js 18+** and npm
- **JDK 17+** and Maven (for backend)
- **Google Gemini API key** (optional, for AI task with Gemini)
  - Get free key from [Google AI Studio](https://aistudio.google.com/app/apikey)

## Setup & Installation

### 1. Start the Backend

```bash
cd phase2-solution/phase2-solution
# For AI task with Gemini API (PowerShell):
$env:GEMINI_API_KEY = "your-free-key"
# For AI task with Gemini API (bash):
export GEMINI_API_KEY=your-free-key
# Start the server
mvn spring-boot:run
# API is live on http://localhost:8080
```

### 2. Setup Frontend

```bash
cd coffee-shop-ui
npm install
npm run dev
# Frontend is live on http://localhost:5173
```

The backend CORS is configured for `http://localhost:5173`.

## API Endpoints

| Method | Path | Purpose |
|--------|------|---------|
| `GET` | `/menu` | List all menu items |
| `GET` | `/menu/available` | List available items only |
| `GET` | `/menu/{id}` | Get single item |
| `POST` | `/menu` | Create new item |
| `PUT` | `/menu/{id}` | Update item |
| `DELETE` | `/menu/{id}` | Delete item |
| `POST` | `/orders` | Place new order |
| `GET` | `/orders` | List all orders |
| `POST` | `/orders/{id}/ready` | Mark PENDING → READY |
| `POST` | `/orders/{id}/pay` | Mark READY → PAID |
| `POST` | `/agent` | Chat with AI barista |

## Key Implementation Details

### API Service Layer (`src/services/apiClient.js`)

- Centralized `apiCall()` wrapper for all fetch requests
- Custom `APIError` class for proper error handling
- Separate API objects: `menuAPI`, `ordersAPI`, `agentAPI`
- Non-2xx responses throw errors that components can catch

**Example usage:**
```javascript
const { menuAPI } = require('./services/apiClient');
const items = await menuAPI.getAll();
```

### Custom Hook: `useMenu` (`src/hooks/useMenu.js`)

Encapsulates all menu-related state and operations:

```javascript
const {
  items,           // Current menu items
  loading,         // Loading state
  error,           // Error message
  fetchItems,      // Refetch all items
  addItem,         // Create new item
  updateItem,      // Update existing item
  deleteItem,      // Delete item
  getItemById,     // Get item by ID
} = useMenu();
```

**Usage in components:**
```jsx
const MenuPage = () => {
  const { items, loading, error, addItem, deleteItem } = useMenu();
  // ... component logic
};
```

### Router Configuration (`src/App.jsx`)

```javascript
<Routes>
  <Route path="/" element={<HomePage />} />
  <Route path="/menu" element={<MenuPage />} />
  <Route path="/menu/:id/edit" element={<EditMenuPage />} />
  <Route path="/orders" element={<OrdersPage />} />
  <Route path="/chat" element={<ChatPage />} />
  <Route path="*" element={<NotFoundPage />} />
</Routes>
```

### AI Chat Integration (`src/pages/ChatPage.jsx`)

- Maintains running conversation log
- Shows typing indicator while waiting for response
- Auto-scrolls to latest message
- Suggested prompts for easy interaction
- Full error handling with user feedback

**Multi-step conversation support:**
The AI can handle complex requests like:
- "Show available coffees, then order a latte and tell me the total"
- "What pastries do you have? I'd like to order two croissants"

Results appear on the Orders page immediately after placing.

## Component Breakdown

### MenuPage
- Form to add new menu items (create)
- Table listing all items with edit/delete buttons
- Loading and error states
- Confirmation dialog before deletion

### EditMenuPage
- Dynamic route `/menu/:id/edit`
- Pre-fills form with current item data
- Validates input before submit
- Navigates back to menu on success
- Shows error if item not found

### OrdersPage
- Browse available items and select for order
- Live running total calculation
- Track order status (PENDING → READY → PAID)
- Update status with action buttons

### ChatPage
- Rich message bubbles for user and agent
- Typing indicator animation
- Auto-scroll on new messages
- Suggested prompt buttons
- Time stamps for each message

### Navigation
- Sticky header with responsive layout
- `NavLink` with active styling
- Mobile-friendly design

## Styling & UX

- **Color scheme**: Modern gradient (purple/blue)
- **Responsive**: Mobile-first design, works on all screen sizes
- **Accessibility**: Proper labels, error messages, focus states
- **Loading states**: Spinners and disabled buttons during operations
- **Error handling**: User-friendly error messages in banners
- **Confirmation dialogs**: Before destructive operations (delete)

## Available Scripts

```bash
npm run dev      # Start development server
npm run build    # Build for production
npm run preview  # Preview production build
```

## Testing Notes

### Without API Key
- Menu CRUD: ✅ Fully functional
- Orders: ✅ Fully functional
- AI Chat: ❌ Will fail (requires backend Gemini key)

### With Gemini API Key
- All features working: ✅
- Multi-step conversation works
- Orders placed via chat appear on Orders page

## Bonus Features Implemented

- ✅ Clean responsive layout that works on mobile
- ✅ Suggested prompts in chat with quick selection
- ✅ Auto-scroll to latest messages
- ✅ Running total calculation before order placement
- ✅ Professional error handling and user feedback
- ✅ Loading indicators for async operations
- ✅ Form validation with error messages

## File Exclusions

`node_modules/` is excluded from version control via `.gitignore`.

## Troubleshooting

**Issue: CORS errors**
- Ensure backend is running on `http://localhost:8080`
- CORS is configured for `http://localhost:5173`

**Issue: API calls fail**
- Check that backend is running: `mvn spring-boot:run`
- Verify endpoints in `src/services/apiClient.js`

**Issue: Chat not working**
- Ensure Gemini API key is set in backend environment
- Check backend logs for API errors

**Issue: Page not loading**
- Check browser console for errors (F12)
- Ensure all dependencies are installed: `npm install`
- Try clearing browser cache and reloading

## Architecture Highlights

1. **Separation of Concerns**
   - API layer separate from components
   - Custom hooks encapsulate state logic
   - Components focus on UI and user interaction

2. **Error Handling**
   - Centralized error handling in API layer
   - Components display user-friendly error messages
   - No silent failures or swallowed errors

3. **State Management**
   - React hooks (`useState`, `useEffect`)
   - Custom `useMenu` hook for complex state
   - Proper dependency arrays to prevent loops

4. **Routing**
   - Client-side routing with React Router
   - Dynamic params for edit operations
   - 404 fallback for unknown routes
   - Programmatic navigation after actions

## Credits

Built with:
- React 18+
- Vite (fast dev server)
- React Router v6
- CSS Grid & Flexbox
- Spring Boot Backend (provided)

---

**Status**: ✅ Complete - All 6 tasks implemented with bonus features
