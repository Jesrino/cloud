import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      "/api": {
        target: "http://localhost:8080",
        changeOrigin: true,
      },
    },
    watch: {
      // ignore heavy or locked asset folders to avoid EBUSY watcher errors on Windows
      ignored: ["**/interface(output)/**", "**/node_modules/**"],
    },
  },
});