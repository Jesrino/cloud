import express from 'express';
import { readFile, writeFile } from 'fs/promises';
import path from 'path';

const app = express();
const PORT = 8080;
const DB = path.join(process.cwd(), 'backend', 'books.json');

app.use(express.json());

async function readBooks() {
  try {
    const txt = await readFile(DB, 'utf8');
    return JSON.parse(txt || '[]');
  } catch (err) {
    return [];
  }
}

async function writeBooks(books) {
  await writeFile(DB, JSON.stringify(books, null, 2), 'utf8');
}

app.get('/api/books', async (req, res) => {
  const books = await readBooks();
  res.json(books);
});

app.get('/api/books/:id', async (req, res) => {
  const books = await readBooks();
  const book = books.find((b) => String(b.id) === String(req.params.id));
  if (!book) return res.status(404).json({ message: 'Not found' });
  res.json(book);
});

app.post('/api/books', async (req, res) => {
  const books = await readBooks();
  const book = req.body;
  // Basic fill-in
  if (!book.id) book.id = crypto?.randomUUID?.() ?? Date.now().toString();
  books.unshift(book);
  await writeBooks(books);
  res.status(201).json(book);
});

app.put('/api/books/:id', async (req, res) => {
  const books = await readBooks();
  const id = String(req.params.id);
  const idx = books.findIndex((b) => String(b.id) === id);
  if (idx === -1) return res.status(404).json({ message: 'Not found' });
  const updated = { ...books[idx], ...req.body, id: books[idx].id };
  books[idx] = updated;
  await writeBooks(books);
  res.json(updated);
});

app.delete('/api/books/:id', async (req, res) => {
  const books = await readBooks();
  const id = String(req.params.id);
  const next = books.filter((b) => String(b.id) !== id);
  await writeBooks(next);
  res.status(204).end();
});

app.listen(PORT, () => {
  console.log(`Backend running on http://localhost:${PORT}`);
});
