import { useParams, Link } from "react-router-dom";

export default function BookDetailPage({ books = [] }) {
  const { id } = useParams();
  const book = books.find((b) => b.id === id);

  if (!book) return <p>Book not found. <Link to="/">Go back</Link></p>;

  return (
    <article className="card">
      <h1>{book.title}</h1>
      <p>by {book.author} · {book.year}</p>
      <p>{book.description}</p>
      <Link to="/">← Back to list</Link>
    </article>
  );
}