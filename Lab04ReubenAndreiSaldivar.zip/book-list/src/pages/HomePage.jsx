import { useState, useMemo } from "react";
import { Link } from "react-router-dom";

export default function HomePage({ books = [], loading, error, onDelete }) {
  const [query, setQuery] = useState("");

  const visibleBooks = useMemo(() => {
    const normalized = query.trim().toLowerCase();
    return books
      .filter((book) => book.title.toLowerCase().includes(normalized))
      .sort((a, b) => a.year - b.year);
  }, [books, query]);

  if (loading) return <div className="spinner" />;
  if (error) return <p className="status error">{error}</p>;
  if (books.length === 0) return <p className="status">No books yet.</p>;

  return (
    <>
      <input
        className="search"
        placeholder="Search title…"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
      />

      <ul className="books">
        {visibleBooks.map((book) => (
          <li key={book.id}>
            <div className="book-row">
              <div>
                <strong>{book.title}</strong> ({book.year})
              </div>
              <div className="row-actions">
                <Link to={`/books/${book.id}/edit`}>Edit</Link>
                <button className="delete" onClick={() => onDelete(book.id)}>
                  Delete
                </button>
              </div>
            </div>
            <div>by {book.author}</div>
            <p>{book.description}</p>
          </li>
        ))}
      </ul>
    </>
  );
}