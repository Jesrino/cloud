import { useState, useEffect } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { getBook } from "../api/books";
import BookForm from "../components/BookForm";

export default function EditBookPage({ onUpdate }) {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState(null);

  useEffect(() => {
    getBook(id).then(setForm);
  }, [id]);

  if (!form) return <div className="spinner" />;

  async function save(updatedBook) {
    await onUpdate(id, updatedBook);
    navigate("/");
  }

  return <BookForm onSubmit={save} initialData={form} submitLabel="Save changes" />;
}
