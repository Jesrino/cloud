import { useNavigate } from "react-router-dom";
import BookForm from "../components/BookForm";

export default function AddBookPage({ onAdd }) {
  const navigate = useNavigate();

  async function handleAdd(book) {
    await onAdd(book);
    navigate("/");
  }

  return <BookForm onSubmit={handleAdd} submitLabel="Add book" />;
}