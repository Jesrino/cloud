import axios from "axios";

const api = axios.create({ baseURL: "/api" });

export const getBooks = () => api.get("/books").then((response) => response.data);
export const getBook = (id) => api.get(`/books/${id}`).then((response) => response.data);
export const createBook = (book) => api.post("/books", book).then((response) => response.data);
export const updateBook = (id, changes) => api.put(`/books/${id}`, changes).then((response) => response.data);
export const deleteBook = (id) => api.delete(`/books/${id}`);
