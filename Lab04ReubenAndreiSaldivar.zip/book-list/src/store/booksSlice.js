import { createSlice } from "@reduxjs/toolkit";
import { booksReducer } from "../reducers/booksReducer";

const booksSlice = createSlice({
  name: "books",
  initialState: [],
  reducers: {
    loadBooks: (state, action) => booksReducer(state, { type: "load", books: action.payload }),
    addBook: (state, action) => booksReducer(state, { type: "add", book: action.payload }),
    updateBook: (state, action) => booksReducer(state, { type: "update", book: action.payload }),
    deleteBook: (state, action) => booksReducer(state, { type: "delete", id: action.payload }),
  },
});

export const { loadBooks, addBook, updateBook, deleteBook } = booksSlice.actions;
export default booksSlice.reducer;
