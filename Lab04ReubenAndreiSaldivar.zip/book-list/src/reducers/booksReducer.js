export function booksReducer(state = [], action) {
  switch (action.type) {
    case "load":
      return action.books;
    case "add":
      return [action.book, ...state];
    case "update":
      return state.map((book) => (book.id === action.book.id ? action.book : book));
    case "delete":
      return state.filter((book) => book.id !== action.id);
    case "clear":
      return [];
    default:
      return state;
  }
}
