import { useState, useEffect } from "react";
import * as api from "../api/books";

export function useBooks() {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    api
      .getBooks()
      .then(setBooks)
      .catch(() => setError("Could not reach the server"))
      .finally(() => setLoading(false));
  }, []);

  const addBook = async (form) => {
    const saved = await api.createBook(form);
    setBooks((prev) => [saved, ...prev]);
  };

  const removeBook = async (id) => {
    await api.deleteBook(id);
    setBooks((prev) => prev.filter((b) => b.id !== id));
  };

  const updateBook = async (id, changes) => {
    const updated = await api.updateBook(id, changes);
    setBooks((prev) => prev.map((b) => (b.id === id ? updated : b)));
  };

  return { books, loading, error, addBook, removeBook, updateBook };
}
