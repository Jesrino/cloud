import { useState, useRef, useEffect } from "react";

const empty = { author: "", title: "", description: "", year: "" };

export default function BookForm({ onSubmit, initialData = empty, submitLabel = "Add book" }) {
  const [form, setForm] = useState(initialData);
  const [errors, setErrors] = useState({});
  const authorRef = useRef(null);

  useEffect(() => {
    authorRef.current?.focus();
  }, []);

  useEffect(() => {
    setForm(initialData);
  }, [initialData]);

  function handleChange(e) {
    setForm({ ...form, [e.target.name]: e.target.value });
  }

  function validate(values) {
    const err = {};
    if (!values.author.trim()) err.author = "Author is required";
    if (!values.title.trim()) err.title = "Title is required";
    if (values.description.trim().length < 10)
      err.description = "Description needs at least 10 characters";
    const yr = Number(values.year);
    if (!values.year) err.year = "Year is required";
    else if (!Number.isInteger(yr) || yr < 1450 || yr > 2026)
      err.year = "Enter a real year (1450 to 2026)";
    return err;
  }

  function handleSubmit() {
    const err = validate(form);
    setErrors(err);
    if (Object.keys(err).length > 0) return;   // stop if invalid
    onSubmit({ ...form, year: Number(form.year), id: form.id ?? crypto.randomUUID() });
    if (!form.id) setForm(empty);
  }

  return (
    <div className="card">
      <h2>{submitLabel === "Add book" ? "Add a book" : "Edit book"}</h2>

      <label>Author</label>
      <input ref={authorRef} name="author" value={form.author} onChange={handleChange} />
      {errors.author && <small className="err">{errors.author}</small>}

      <label>Title</label>
      <input name="title" value={form.title} onChange={handleChange} />
      {errors.title && <small className="err">{errors.title}</small>}

      <label>Description</label>
      <textarea name="description" value={form.description} onChange={handleChange} />
      {errors.description && <small className="err">{errors.description}</small>}

      <label>Year</label>
      <input name="year" type="number" value={form.year} onChange={handleChange} />
      {errors.year && <small className="err">{errors.year}</small>}

      <button onClick={handleSubmit}>{submitLabel}</button>
    </div>
  );
}