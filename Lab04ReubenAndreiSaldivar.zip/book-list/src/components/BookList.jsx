export default function BookList({ books }) {
  if (books.length === 0) return <p>No books yet. Add one above.</p>;

  return (
    <ul className="books">
      {books.map((b) => (
        <li key={b.id}>
          <strong>{b.title}</strong> ({b.year})
          <div>by {b.author}</div>
          <p>{b.description}</p>
        </li>
      ))}
    </ul>
  );
}